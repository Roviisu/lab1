
package com.mycompany.p05q02;


public class Poltician implements Speaker
{
    
    @Override
    public void speak() {
        System.out.println("Hello");
    }
}
