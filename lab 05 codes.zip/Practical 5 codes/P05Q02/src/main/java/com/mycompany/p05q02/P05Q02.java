
package com.mycompany.p05q02;


public class P05Q02
{

    public static void main(String[] args)
    {
       Lecturer L1=new Lecturer();
       L1.speak();
       Poltician P1=new Poltician();
       P1.speak();
       Priest PR1=new Priest();
       PR1.speak();
       

    }
}