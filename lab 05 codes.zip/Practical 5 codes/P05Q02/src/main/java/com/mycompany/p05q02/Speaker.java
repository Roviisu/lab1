package com.mycompany.p05q02;

public interface Speaker 
{
  void speak();  
}
