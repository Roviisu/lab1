package com.mycompany.p05q02;


public class Priest implements Speaker
{
    @Override
    public void speak()
    {
        System.out.println("Every One");
    }
}
