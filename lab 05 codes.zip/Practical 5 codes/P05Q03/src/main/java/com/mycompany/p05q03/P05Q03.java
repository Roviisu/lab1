package com.mycompany.p05q03;

public class P05Q03
{

    public static void main(String[] args)
    {
       Undergraduate U1=new Undergraduate();
       U1.display();
    }
}
