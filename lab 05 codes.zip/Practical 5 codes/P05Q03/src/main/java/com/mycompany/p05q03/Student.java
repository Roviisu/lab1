package com.mycompany.p05q03;

public abstract class Student 
{
    final int marks=100;
    final void display()
    {
        System.out.println("Marks:"+marks);
    }
    
}
