package com.mycompany.p05q03;

public class Undergraduate extends Student
{
    
}
