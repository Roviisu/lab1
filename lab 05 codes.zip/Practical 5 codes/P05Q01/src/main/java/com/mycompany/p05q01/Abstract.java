package com.mycompany.p05q01;

public abstract class Abstract
{
    public abstract void display();
    public void Display()
    {
        int x=5;
        System.out.println("X:"+x);
    }
    
}
