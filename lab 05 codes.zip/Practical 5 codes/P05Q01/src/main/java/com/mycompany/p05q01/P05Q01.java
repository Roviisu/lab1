package com.mycompany.p05q01;

public class P05Q01 
{

    public static void main(String[] args)
    {
        classs obj1=new classs();
        obj1.display();
    }
}
