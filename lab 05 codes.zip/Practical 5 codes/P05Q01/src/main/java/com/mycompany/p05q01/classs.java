
package com.mycompany.p05q01;


public class classs extends Abstract
{
    public void display()
    {
        int x=10;
        System.out.println("X:"+x);
    }
    
}
