
package com.mycompany.animal;


public class Mammal extends Animal
{
    
}
