
package com.mycompany.animal;


public class Dog extends Mammal
{
    
}
