
package com.mycompany.animal;

public class Reptile extends Animal
{
    
}
