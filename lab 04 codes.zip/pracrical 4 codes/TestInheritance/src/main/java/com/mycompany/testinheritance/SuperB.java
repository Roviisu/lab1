
package com.mycompany.testinheritance;


public class SuperB 
{
    int x;
    void setIt(int n){x=n;}
    void increase(){x=x+1;}
    void triple(){x=x*3;};
    int returnIt(){return x;}
    
}
