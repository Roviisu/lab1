
package com.mycompany.practicalnq3;


public class Person 
{
   private int ID;
   private String name;
   
   public Person(int id,String name)
   {
       this.ID=id;
       this.name=name;
   }
   public int getID()
   {
       return ID;
       
   }
   public String getName()
   {
       return name;
   }
           
}
