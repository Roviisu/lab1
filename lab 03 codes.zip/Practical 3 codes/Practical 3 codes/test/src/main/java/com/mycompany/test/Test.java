
package com.mycompany.test;


public class Test
{

    public static void main(String[] args)
    {
       Employee E1=new Employee("Jeneesha",21,250000.00f);
       
        System.out.println(E1.getName());
     
        System.out.println(E1.getAge());
     
        System.out.println(E1.getSalary());
       
    }
}
