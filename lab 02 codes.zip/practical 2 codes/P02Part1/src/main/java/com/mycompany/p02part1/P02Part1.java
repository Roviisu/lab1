package com.mycompany.p02part1;
public class P02Part1 
{

    public static void main(String[] args) 
    {
        Item I1=new Item(1111,"Paris");
        I1.getter();
        
    }
}
